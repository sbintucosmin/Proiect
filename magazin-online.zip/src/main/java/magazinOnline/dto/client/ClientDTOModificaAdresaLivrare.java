package magazinOnline.dto.client;

public class ClientDTOModificaAdresaLivrare {
    String adresaLivrare;

    public String getAdresaLivrare() {
        return adresaLivrare;
    }
}
