package magazinOnline.dto.client;

public class ClientDTOContNou {
    String nume;
    String adresaLivrare;

    public String getNume() {
        return nume;
    }

    public String getAdresaLivrare() {
        return adresaLivrare;
    }
}
