package magazinOnline.dto.produs;

public class ProdusDTOAdaugaProdus {
    String numeProdus;
    double pret;
    String categorie;

    public String getNumeProdus() {
        return numeProdus;
    }

    public double getPret() {
        return pret;
    }

    public String getCategorie() {
        return categorie;
    }
}
