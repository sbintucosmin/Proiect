package magazinOnline.dto.produs;

public class ProdusDTOModificaProdus {
    String numeProdus;
    double pret;

    public String getNumeProdus() {
        return numeProdus;
    }

    public double getPret() {
        return pret;
    }
}
