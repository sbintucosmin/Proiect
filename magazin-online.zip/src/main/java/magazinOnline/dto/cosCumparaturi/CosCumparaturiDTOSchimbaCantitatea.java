package magazinOnline.dto.cosCumparaturi;

public class CosCumparaturiDTOSchimbaCantitatea {
    int cantitate;

    public int getCantitate() {
        return cantitate;
    }
}
