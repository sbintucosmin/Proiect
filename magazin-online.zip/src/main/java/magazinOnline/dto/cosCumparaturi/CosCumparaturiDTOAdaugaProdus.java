package magazinOnline.dto.cosCumparaturi;

public class CosCumparaturiDTOAdaugaProdus {
    String numeProdus;
    int cantitate;
    String numeClient;

    public String getNumeProdus() {
        return numeProdus;
    }

    public int getCantitate() {
        return cantitate;
    }

    public String getNumeClient() {
        return numeClient;
    }
}
